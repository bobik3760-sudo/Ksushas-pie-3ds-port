# Ksusha cooks a pie 3 — Nintendo 3DS port

Port of the Pocket Code (Catrobat) game **"Ксюша готовит пирог 3"** to 3DS homebrew
(C, devkitARM + libctru + citro2d). Icon = `icon.png` (48×48), banner = `banner.png` (256×128).

## Status — please read
* The game logic, converted assets, screen layout and touch mapping were **tested on Linux** with
  `sim/run_sim.sh` (a software renderer + a bot that plays all 9 scenes; screenshots in `preview/`).
* The 3DS-specific file `source/main.c` was **not compiled or run on a real 3DS** (no devkitPro
  was available where this was written). It only uses standard libctru/citro2d calls and passes a
  syntax check, but expect to possibly fix a typo on the first real build.
* Things to check on the first run on hardware: sprite rotation direction (`ROT_SIGN` at the top
  of `main.c`, set to `-1.0f` if the flour/egg turn away from their target), and sound (needs
  `sdmc:/3ds/dspfirm.cdc` — dump it with DSP1; without it the game runs silently).

## Build
**A. Without installing anything: GitHub Actions.** Push this folder to a GitHub repo, open the
*Actions* tab → *Build 3DSX* → download the `KsushaPie3DS.3dsx` artifact.

**B. Locally** (see the two tutorials you linked): install devkitPro with the `3ds-dev` package group, then

    make            # -> KsushaPie3DS.3dsx  (icon is embedded as .smdh)
    make cia        # optional, needs bannertool + makerom; uses banner.png. app.rsf is untested

Copy the `.3dsx` to `sdmc:/3ds/` and start it from the Homebrew Launcher (or citra: `citra KsushaPie3DS.3dsx`).

## Controls
| Input | Action |
|---|---|
| Touch the bottom screen | tap / drag (bottom screen = mini view of the stage inside the green grid pad) |
| Circle Pad / D-Pad | move the crosshair cursor (it is also the "touch position" for the hand in the mixing scene) |
| A / B / X / Y | tap at the cursor |
| R / L | cursor fast / slow |
| SELECT | restart from the splash screen |
| START | exit to the Home Menu |

## What was ported (all 9 scenes, from `code.xml`)
splash (face pops in 30→40→70 %, 6.6 s) → title (background flips every 1 s, music loops, tap ИГРАТЬ) →
flour chases a random point, tap it → egg chases a random point, tap it → cow: tap the red button, bucket
fills (+water sound) → hand follows your touch (5 s, then next background) → oven: a fire sprite
teleports and clones itself every frame for 10 s → tap the pie to eat it (crunch sound, next look) →
Ksusha spins forever (music).

Pocket Code behaviour is kept: 2507×1220 stage, y up, 60 steps/s, "Forever" = one iteration per frame,
Wait ≥ 1 frame, direction/rotation, random position, clones (max 500), broadcast restarts, scene switches stop sounds.

## Differences from the phone version (on purpose)
* The stage is scaled uniformly (no stretching): 400×195 px on the top screen with black bars.
* Taps also work slightly outside a sprite (≈ 45 stage units) because 3DS pixels are small, and the topmost
  sprite *that reacts to taps* gets the touch (so the rooster can't block the egg).
* Sprites are pre-scaled to the 3DS resolution by the converter, textures are loaded per scene.
* The small orange scribble in your mock-up image is not part of the Pocket Code project (the chase "targets"
  are 1-pixel invisible sprites), so it isn't drawn.

## Files
    source/game.c      engine: Pocket Code brick interpreter (platform independent)
    source/gamedata.c  GENERATED scenes/scripts (from code.xml)
    source/ui.c        screen layout + bottom-screen pad (shared with the simulator)
    source/main.c      3DS front end: citro2d, ndsp audio, touch/buttons
    romfs/             GENERATED textures (.tex, PICA200-swizzled RGBA8), 32 kHz PCM sounds, grid.tex
    tools/convert.py   .catrobat -> romfs + gamedata.c      tools/make_ui.py   grid/icon/banner
    sim/               Linux simulator (bot plays the game)  preview/  screenshots from the simulator

Regenerate assets after changing the Pocket Code project: `tools/rebuild_assets.sh project.catrobat`
(needs python3, numpy, pillow, ffmpeg). The converter supports the bricks this game uses and stops with an
error on any other brick, so new bricks are easy to add in `convert.py` + `game.c`.
