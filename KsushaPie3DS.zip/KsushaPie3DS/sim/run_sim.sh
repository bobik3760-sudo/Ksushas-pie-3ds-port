#!/bin/sh
# Plays the whole game with a bot on Linux (software renderer) and writes PNG screenshots to preview/
set -e
cd "$(dirname "$0")/.."
gcc -O2 -Wall -Isource sim/sim.c source/game.c source/gamedata.c source/ui.c -lm -o sim/sim
./sim/sim
python3 tools/ppm2png.py
