#!/bin/sh
# Regenerates romfs/ and source/gamedata.c from the Pocket Code project.
# usage: tools/rebuild_assets.sh path/to/project.catrobat
# needs: python3 + numpy + pillow, ffmpeg
set -e
cd "$(dirname "$0")/.."
python3 tools/convert.py "$1" .
python3 tools/make_ui.py assets_src/ref_layout.png assets_src/icon_source.png assets_src/banner_source.png
