#!/bin/sh
# Plays the whole game with a bot on Linux (software renderer); PNG screenshots go to preview/
set -e
cd "$(dirname "$0")/.."
[ -d romfs ] || unzip -q assets.zip
gcc -O2 -Wall -I. sim/sim.c game.c gamedata.c ui.c -lm -o sim/sim
./sim/sim
python3 tools/ppm2png.py
