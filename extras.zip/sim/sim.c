/*
 * Headless Linux simulator: implements the platform layer in software and
 * plays the whole game with a scripted "bot" so game.c / ui.c / the converted
 * assets can be tested without a 3DS.  Writes PPM screenshots to ./out/.
 *
 *   gcc -O2 -Isource sim/sim.c source/game.c source/gamedata.c source/ui.c -lm -o sim/sim
 *   ./sim/sim            (run from the project root)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include "game.h"
#include "ui.h"

struct Tex { int w, h, tw, th; uint8_t *rgba; };

static uint8_t fbt[TOP_W * SCR_H * 3], fbb[BOT_W * SCR_H * 3];
static uint8_t *fb = fbt; static int fbw = TOP_W;

static double simtime = 0;
static FILE *snd_log;

Tex *plat_tex_load_file(const char *rel)
{
    char path[128];
    snprintf(path, sizeof path, "romfs/%s", rel);
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "missing %s\n", path); return NULL; }
    uint16_t hd[4];
    if (fread(hd, 2, 4, f) != 4) return NULL;
    Tex *t = calloc(1, sizeof *t);
    t->w = hd[0]; t->h = hd[1]; t->tw = hd[2]; t->th = hd[3];
    size_t bytes = (size_t)t->tw * t->th * 4;
    uint8_t *raw = malloc(bytes);
    if (fread(raw, 1, bytes, f) != bytes) { fprintf(stderr, "short %s\n", path); exit(1); }
    fclose(f);
    t->rgba = malloc(bytes);
    /* inverse of the PICA200 swizzle used by tools/convert.py */
    for (int ty = 0; ty < t->th / 8; ty++)
        for (int tx = 0; tx < t->tw / 8; tx++)
            for (int z = 0; z < 64; z++) {
                int x = (z & 1) | ((z >> 1) & 2) | ((z >> 2) & 4);
                int y = ((z >> 1) & 1) | ((z >> 2) & 2) | ((z >> 3) & 4);
                int m = ty * 8 + y, col = tx * 8 + x, r = t->th - 1 - m;
                const uint8_t *p = raw + ((size_t)(ty * (t->tw / 8) + tx) * 64 + z) * 4;   /* A,B,G,R */
                uint8_t *d = t->rgba + ((size_t)r * t->tw + col) * 4;
                d[0] = p[3]; d[1] = p[2]; d[2] = p[1]; d[3] = p[0];
            }
    free(raw);
    return t;
}
void plat_tex_free(Tex *t) { if (t) { free(t->rgba); free(t); } }

static inline void blend(int x, int y, float r, float g, float b, float a)
{
    if (x < 0 || y < 0 || x >= fbw || y >= SCR_H) return;
    uint8_t *p = fb + ((size_t)y * fbw + x) * 3;
    p[0] = (uint8_t)(p[0] + (r * 255 - p[0]) * a);
    p[1] = (uint8_t)(p[1] + (g * 255 - p[1]) * a);
    p[2] = (uint8_t)(p[2] + (b * 255 - p[2]) * a);
}

void plat_rect(float x, float y, float w, float h, float r, float g, float b, float a)
{
    for (int j = (int)floorf(y + 0.5f); j < (int)floorf(y + h + 0.5f); j++)
        for (int i = (int)floorf(x + 0.5f); i < (int)floorf(x + w + 0.5f); i++)
            blend(i, j, r, g, b, a);
}

static void texel(const Tex *t, float u, float v, float out[4])
{
    /* bilinear, clamp inside the real image area, premultiplied for correct edges */
    float fx = u - 0.5f, fy = v - 0.5f;
    int x0 = (int)floorf(fx), y0 = (int)floorf(fy);
    float ax = fx - x0, ay = fy - y0;
    float acc[4] = { 0, 0, 0, 0 };
    for (int j = 0; j < 2; j++)
        for (int i = 0; i < 2; i++) {
            int xx = x0 + i, yy = y0 + j;
            float wgt = (i ? ax : 1 - ax) * (j ? ay : 1 - ay);
            if (xx < 0) xx = 0;
            if (xx >= t->w) xx = t->w - 1;
            if (yy < 0) yy = 0;
            if (yy >= t->h) yy = t->h - 1;
            const uint8_t *p = t->rgba + ((size_t)yy * t->tw + xx) * 4;
            float a = p[3] / 255.0f;
            acc[0] += wgt * p[0] / 255.0f * a; acc[1] += wgt * p[1] / 255.0f * a;
            acc[2] += wgt * p[2] / 255.0f * a; acc[3] += wgt * a;
        }
    out[0] = acc[0]; out[1] = acc[1]; out[2] = acc[2]; out[3] = acc[3];
}

void plat_draw(Tex *t, float cx, float cy, float w, float h, float ang, float alpha)
{
    if (!t || w <= 0 || h <= 0) return;
    float ca = cosf(ang), sa = sinf(ang);
    float rad = 0.5f * sqrtf(w * w + h * h);
    int x0 = (int)floorf(cx - rad), x1 = (int)ceilf(cx + rad);
    int y0 = (int)floorf(cy - rad), y1 = (int)ceilf(cy + rad);
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > fbw) x1 = fbw;
    if (y1 > SCR_H) y1 = SCR_H;
    for (int py = y0; py < y1; py++)
        for (int px = x0; px < x1; px++) {
            float dx = px + 0.5f - cx, dy = py + 0.5f - cy;
            /* clockwise rotation on a y-down screen: inverse maps back to the image */
            float lx = dx * ca + dy * sa, ly = -dx * sa + dy * ca;
            if (lx < -w / 2 || lx >= w / 2 || ly < -h / 2 || ly >= h / 2) continue;
            float c[4];
            texel(t, (lx / w + 0.5f) * t->w, (ly / h + 0.5f) * t->h, c);
            if (c[3] <= 0.001f) continue;
            uint8_t *p = fb + ((size_t)py * fbw + px) * 3;
            float a = alpha;
            p[0] = (uint8_t)(p[0] * (1 - c[3] * a) + c[0] * 255 * a);
            p[1] = (uint8_t)(p[1] * (1 - c[3] * a) + c[1] * 255 * a);
            p[2] = (uint8_t)(p[2] * (1 - c[3] * a) + c[2] * 255 * a);
        }
}

void plat_draw_part(Tex *t, int sx, int sy, int sw, int sh, float dx, float dy)
{
    if (!t) return;
    for (int j = 0; j < sh; j++)
        for (int i = 0; i < sw; i++) {
            const uint8_t *p = t->rgba + ((size_t)(sy + j) * t->tw + (sx + i)) * 4;
            blend((int)dx + i, (int)dy + j, p[0] / 255.f, p[1] / 255.f, p[2] / 255.f, p[3] / 255.f);
        }
}

void plat_text(const char *s, float x, float y, float scale, float r, float g, float b)
{ (void)s; (void)x; (void)y; (void)scale; (void)r; (void)g; (void)b; }

void plat_snd_play(int id) { fprintf(snd_log, "%7.2fs play sound %d (%.2fs)\n", simtime, id, g_sounds[id].samples / (float)SND_RATE); }
void plat_snd_stop_all(void) { fprintf(snd_log, "%7.2fs stop all sounds\n", simtime); }

/* ------------------------------------------------------------------ bot */
static void dump(const char *name)
{
    /* top | bottom side by side as PPM (converted to PNG by tools/ppm2png.py) */
    char path[128];
    snprintf(path, sizeof path, "out/%s.ppm", name);
    FILE *f = fopen(path, "wb");
    fprintf(f, "P6\n%d %d\n255\n", TOP_W + BOT_W + 10, SCR_H);
    for (int y = 0; y < SCR_H; y++) {
        fwrite(fbt + (size_t)y * TOP_W * 3, 1, TOP_W * 3, f);
        uint8_t gap[30]; memset(gap, 40, sizeof gap); fwrite(gap, 1, 30, f);
        fwrite(fbb + (size_t)y * BOT_W * 3, 1, BOT_W * 3, f);
    }
    fclose(f);
}

static void render(float cx, float cy, bool cur)
{
    fb = fbt; fbw = TOP_W; ui_draw_top(cur, cx, cy);
    fb = fbb; fbw = BOT_W; ui_draw_bottom(cur, cx, cy);
}

static void bot_tap(float sx, float sy, float *cx, float *cy)
{
    float k = (float)BOT_W / g_stage_w;
    int px = (int)lroundf(BOT_W / 2.0f + sx * k), py = (int)lroundf(SCR_H / 2.0f - sy * k);
    ui_touch_to_stage(px, py, cx, cy);          /* the same path a real touch takes */
    game_tap(*cx, *cy);
}

int main(void)
{
    if (system("mkdir -p out")) return 1;
    snd_log = fopen("out/sound.log", "w");
    ui_init();
    game_init();
    const float dt = 1.0f / 60.0f;
    float cx = 0, cy = 0;
    int last_scene = -1; double scene_t = 0;
    int taps = 0; bool dumped_a = false, dumped_b = false;
    int total = 60 * 140;
    for (int f = 0; f < total; f++) {
        simtime = f * dt;
        game_set_touch(cx, cy);
        game_update(dt);
        int sc = game_scene();
        if (sc != last_scene) {
            printf("[%6.2fs] scene %d: %s\n", simtime, sc, game_scene_name());
            last_scene = sc; scene_t = 0; taps = 0; dumped_a = dumped_b = false;
        }
        scene_t += dt;
        char nm[64];
        /* bot behaviour per scene index */
        switch (sc) {
        case 1: if (scene_t > 2.2 && !taps) { bot_tap(-647, -303, &cx, &cy); taps++; } break;
        case 2: case 3: if (scene_t > 3.0 && !taps) {
                    const Inst *s = game_inst(1); bot_tap(s->x, s->y, &cx, &cy); taps++; } break;
        case 4: if (scene_t > 1.5 && !taps) { bot_tap(-70, -80, &cx, &cy); taps++; } break;
        case 5: { /* drag the hand around */
                    cx = 500 * sinf((float)scene_t * 1.5f); cy = -100 + 250 * cosf((float)scene_t * 2.0f); } break;
        case 7: if (scene_t > 1.0 && taps < 5 && fmod(scene_t, 0.7) < dt) { bot_tap(-1, -81, &cx, &cy); taps++; } break;
        }
        if (!dumped_a && scene_t > 1.2) { render(cx, cy, sc != 5); snprintf(nm, sizeof nm, "s%d_a", sc); dump(nm); dumped_a = true; }
        if (!dumped_b && scene_t > (sc == 5 ? 5.5 : sc == 7 ? 6.0 : 3.6)) { render(cx, cy, sc != 5); snprintf(nm, sizeof nm, "s%d_b", sc); dump(nm); dumped_b = true; }
        if (sc == 8 && scene_t > 4.0) break;
    }
    printf("finished at scene %d (%s)\n", game_scene(), game_scene_name());
    fclose(snd_log);
    return 0;
}
