#!/bin/sh
# Regenerates assets.zip and gamedata.c from the Pocket Code project (run from the repo root).
# usage: sh tools/rebuild_assets.sh path/to/project.catrobat     needs: python3, numpy, pillow, ffmpeg, zip
set -e
cd "$(dirname "$0")/.."
mkdir -p preview
python3 tools/convert.py "$1" .
python3 tools/make_ui.py assets_src/ref_layout.png assets_src/icon_source.png assets_src/banner_source.png
rm -f assets.zip && zip -r -q assets.zip romfs && rm -rf romfs
