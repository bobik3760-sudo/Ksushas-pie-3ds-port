#!/usr/bin/env python3
"""Builds romfs/grid.tex (bottom-screen pad), icon.png (48x48), banner.png (256x128), banner.wav (silent)."""
import sys, os, wave
import numpy as np
from PIL import Image
sys.path.insert(0, os.path.dirname(__file__))
from convert import swizzle_rgba8, pow2

ref, icon, banner = sys.argv[1:4]
out = os.path.join(os.path.dirname(__file__), '..')

# --- green grid cropped out of the reference mock-up -> 320x240 (4:3 centre crop)
im = Image.open(ref).convert('RGBA')
a = np.asarray(im).astype(int)
mask = (a[..., 1] > 150) & (a[..., 0] < 170) & (a[..., 2] < 170) & (a[..., 3] > 200)
ys, xs = np.where(mask)
# the grid is the big green region in the lower part of the picture
ys_sel = ys > 615
x0, x1 = xs[ys_sel].min(), xs[ys_sel].max()
y0, y1 = ys[ys_sel].min(), ys[ys_sel].max()
print('grid bbox', x0, y0, x1, y1)
w, h = x1 - x0, y1 - y0
cw = int(h * 4 / 3)
if cw > w:
    ch = int(w * 3 / 4); cw = w
else:
    ch = h
cx0 = x0 + (w - cw) // 2; cy0 = y0 + (h - ch) // 2
crop = im.crop((cx0 + 6, cy0 + 6, cx0 + cw - 6, cy0 + ch - 6)).convert('RGB').resize((320, 240), Image.LANCZOS)
crop.save(out + '/preview/grid_preview.png')
arr = np.zeros((256, 512, 4), np.uint8)
arr[:240, :320, :3] = np.asarray(crop); arr[:240, :320, 3] = 255
with open(out + '/romfs/grid.tex', 'wb') as f:
    f.write(np.array([320, 240, 512, 256], '<u2').tobytes())
    f.write(swizzle_rgba8(arr))

# --- icon (48x48) and banner (256x128)
Image.open(icon).convert('RGBA').resize((48, 48), Image.LANCZOS).save(out + '/icon.png')
b = Image.open(banner).convert('RGBA')
bb = Image.new('RGBA', (256, 128), (0, 0, 0, 255))
bb.alpha_composite(b.resize((256, 128), Image.LANCZOS))
bb.save(out + '/banner.png')
# silent 3 second banner sound (bannertool wants a wav)
with wave.open(out + '/banner.wav', 'wb') as wv:
    wv.setnchannels(2); wv.setsampwidth(2); wv.setframerate(32000)
    wv.writeframes(b'\x00' * (32000 * 4 * 3))
print('ok')
