#!/usr/bin/env python3
"""Converts out/*.ppm simulator screenshots to PNG and builds preview/contact sheets."""
import glob, os, sys
from PIL import Image
os.makedirs('preview', exist_ok=True)
for p in sorted(glob.glob('out/*.ppm')):
    Image.open(p).save('preview/' + os.path.basename(p)[:-4] + '.png')
