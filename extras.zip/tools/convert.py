#!/usr/bin/env python3
"""
Pocket Code (.catrobat) -> Nintendo 3DS asset/data converter.

Reads code.xml from the project, converts every look to a pre-scaled, GPU-swizzled
RGBA8 texture (romfs/tex/NNN.tex), every sound to raw 32 kHz stereo PCM16
(romfs/snd/NN.pcm) and writes source/gamedata.c with all scenes, sprites and
brick scripts flattened into plain C arrays.

usage: python3 tools/convert.py "project.catrobat" [outdir=.]
needs: python3, numpy, pillow, ffmpeg
"""
import sys, os, zipfile, hashlib, subprocess, tempfile, shutil
import xml.etree.ElementTree as ET
import numpy as np
from PIL import Image

TOP_W = 400.0           # 3DS top screen width in pixels
SND_RATE = 32000


def pow2(n, lo=8):
    p = lo
    while p < n:
        p <<= 1
    return p


def morton(x, y):
    z = 0
    for b in range(3):
        z |= ((x >> b) & 1) << (2 * b)
        z |= ((y >> b) & 1) << (2 * b + 1)
    return z


def swizzle_rgba8(arr):
    """arr: (th, tw, 4) uint8 RGBA, row 0 = image top. Returns PICA200 tiled bytes."""
    th, tw, _ = arr.shape
    arr = arr[::-1]                                # GPU textures start at the bottom row
    abgr = np.ascontiguousarray(arr[..., ::-1])    # bytes in memory: A,B,G,R
    t = abgr.reshape(th // 8, 8, tw // 8, 8, 4).transpose(0, 2, 1, 3, 4)
    out = np.empty((th // 8, tw // 8, 64, 4), np.uint8)
    for y in range(8):
        for x in range(8):
            out[:, :, morton(x, y)] = t[:, :, y, x]
    return out.tobytes()


def fval(f):
    if f is None:
        return 0.0
    ty = f.findtext('type')
    v = f.findtext('value')
    l = f.find('leftChild')
    r = f.find('rightChild')
    if ty == 'NUMBER':
        return float(v)
    if ty == 'OPERATOR':
        a = fval(l) if l is not None else None
        b = fval(r)
        if v == 'MINUS':
            return -b if a is None else a - b
        if v == 'PLUS':
            return b if a is None else a + b
        if v == 'MULT':
            return a * b
        if v == 'DIVIDE':
            return a / b
    raise SystemExit('unsupported formula: %s %s' % (ty, v))


def formulas(brick):
    fl = brick.find('formulaList')
    return {f.get('category'): fval(f) for f in fl.findall('formula')} if fl is not None else {}


def main():
    src = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else '.'
    work = tempfile.mkdtemp()
    zipfile.ZipFile(src).extractall(work)
    root = ET.parse(os.path.join(work, 'code.xml')).getroot()
    hdr = root.find('header')
    SW = int(hdr.findtext('screenWidth'))
    SH = int(hdr.findtext('screenHeight'))
    kt = TOP_W / SW
    print('stage %dx%d, top-screen scale %.5f' % (SW, SH, kt))

    for d in ('tex', 'snd'):
        os.makedirs('%s/romfs/%s' % (out, d), exist_ok=True)
        for f in os.listdir('%s/romfs/%s' % (out, d)):
            os.remove('%s/romfs/%s/%s' % (out, d, f))

    scenes_xml = root.find('scenes').findall('scene')
    scene_names = [s.findtext('name') for s in scenes_xml]
    messages = {}

    def msg_id(name):
        return messages.setdefault(name, len(messages))

    tex_cache = {}
    tex_list = []
    snd_cache = {}
    snd_list = []

    def add_texture(path, size_pct):
        im = Image.open(path).convert('RGBA')
        sw, sh = im.size
        tw_img = min(1024, max(4, int(round(sw * kt * size_pct / 100.0))))
        th_img = min(1024, max(4, int(round(sh * kt * size_pct / 100.0))))
        key = (hashlib.sha1(open(path, 'rb').read()).hexdigest(), tw_img, th_img)
        if key in tex_cache:
            return tex_cache[key], sw, sh
        small = im.convert('RGBa').resize((tw_img, th_img), Image.LANCZOS).convert('RGBA')
        tw, th = pow2(tw_img), pow2(th_img)
        canvas = np.zeros((th, tw, 4), np.uint8)
        canvas[:th_img, :tw_img] = np.asarray(small)
        tid = len(tex_list)
        with open('%s/romfs/tex/%03d.tex' % (out, tid), 'wb') as f:
            f.write(np.array([tw_img, th_img, tw, th], '<u2').tobytes())
            f.write(swizzle_rgba8(canvas))
        tex_cache[key] = tid
        tex_list.append((tw_img, th_img, tw, th))
        return tid, sw, sh

    def add_sound(path):
        key = hashlib.sha1(open(path, 'rb').read()).hexdigest()
        if key in snd_cache:
            return snd_cache[key]
        sid = len(snd_list)
        dst = '%s/romfs/snd/%02d.pcm' % (out, sid)
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', path, '-f', 's16le',
                        '-ar', str(SND_RATE), '-ac', '2', dst], check=True)
        snd_cache[key] = sid
        snd_list.append(os.path.getsize(dst) // 4)
        return sid

    C = []
    scene_c = []

    for si, sc in enumerate(scenes_xml):
        sname = sc.findtext('name')
        objl = sc.find('objectList')
        resolved = []
        for o in list(objl):
            if o.get('reference'):
                path = o.get('reference')
                assert path.startswith('../')
                tgt = objl.find(path[3:])
                assert tgt is not None, path
                resolved.append(tgt)
            else:
                resolved.append(o)
        names = [o.get('name') for o in resolved]

        spr_c = []
        for pi, o in enumerate(resolved):
            maxsize = 100.0
            for b in o.iter('brick'):
                if b.get('type') == 'SetSizeToBrick':
                    maxsize = max(maxsize, formulas(b)['SIZE'])
            looks = []
            ll = o.find('lookList')
            for l in (ll if ll is not None else []):
                p = os.path.join(work, sname, 'images', l.get('fileName'))
                tid, w, h = add_texture(p, maxsize)
                looks.append((tid, w, h))
            sounds = {}
            first_sound = None
            sl = o.find('soundList')
            for s in (sl if sl is not None else []):
                sid = add_sound(os.path.join(work, sname, 'sounds', s.get('fileName')))
                sounds[s.get('fileName')] = sid
                if first_sound is None:
                    first_sound = sid

            scripts_c = []
            slist = o.find('scriptList')
            for si2, s in enumerate(slist if slist is not None else []):
                stype = s.get('type')
                if stype == 'StartScript':
                    kind, m = 'SC_START', 0
                elif stype == 'WhenScript':
                    kind, m = 'SC_TAP', 0
                elif stype == 'BroadcastScript':
                    kind, m = 'SC_BROADCAST', msg_id(s.findtext('receivedMessage'))
                else:
                    raise SystemExit('unsupported script type ' + stype)
                bricks = []

                def emit(b):
                    t = b.get('type')
                    f = formulas(b)
                    if b.findtext('commentedOut') == 'true':
                        return
                    if t == 'PlaceAtBrick':
                        bricks.append(('OP_PLACE_AT', f['X_POSITION'], f['Y_POSITION'], 0))
                    elif t == 'HideBrick':
                        bricks.append(('OP_HIDE', 0, 0, 0))
                    elif t == 'ShowBrick':
                        bricks.append(('OP_SHOW', 0, 0, 0))
                    elif t == 'WaitBrick':
                        bricks.append(('OP_WAIT', f['TIME_TO_WAIT_IN_SECONDS'], 0, 0))
                    elif t == 'SetSizeToBrick':
                        bricks.append(('OP_SET_SIZE', f['SIZE'], 0, 0))
                    elif t == 'NextLookBrick':
                        bricks.append(('OP_NEXT_LOOK', 0, 0, 0))
                    elif t == 'MoveNStepsBrick':
                        bricks.append(('OP_MOVE_STEPS', f['STEPS'], 0, 0))
                    elif t == 'TurnLeftBrick':
                        bricks.append(('OP_TURN_LEFT', f['TURN_LEFT_DEGREES'], 0, 0))
                    elif t == 'TurnRightBrick':
                        bricks.append(('OP_TURN_RIGHT', f['TURN_RIGHT_DEGREES'], 0, 0))
                    elif t == 'CloneBrick':
                        bricks.append(('OP_CLONE', 0, 0, 0))
                    elif t == 'BroadcastBrick':
                        bricks.append(('OP_BROADCAST', 0, 0, msg_id(b.findtext('broadcastMessage'))))
                    elif t == 'SceneStartBrick':
                        bricks.append(('OP_SCENE_START', 0, 0, scene_names.index(b.findtext('sceneToStart'))))
                    elif t == 'GoToBrick':
                        sel = int(b.findtext('spinnerSelection'))
                        if sel == 80:
                            bricks.append(('OP_GOTO_TOUCH', 0, 0, 0))
                        elif sel == 81:
                            bricks.append(('OP_GOTO_RANDOM', 0, 0, 0))
                        else:
                            raise SystemExit('unsupported GoTo target %d' % sel)
                    elif t == 'PointToBrick':
                        po = b.find('pointedObject')
                        nm = po.get('name')
                        if nm is None:
                            nm = objl.find(po.get('reference')[3:]).get('name')
                        bricks.append(('OP_POINT_TO', 0, 0, names.index(nm)))
                    elif t in ('PlaySoundBrick', 'PlaySoundAndWaitBrick'):
                        sd = b.find('sound')
                        sid = first_sound
                        if sd is not None and sd.get('fileName'):
                            sid = sounds[sd.get('fileName')]
                        bricks.append(('OP_PLAY_SOUND' if t == 'PlaySoundBrick' else 'OP_PLAY_SOUND_WAIT', 0, 0, sid))
                    elif t == 'ForeverBrick':
                        bricks.append(('OP_FOREVER', 0, 0, 0))
                        start = len(bricks)
                        for c in b.find('loopBricks').findall('brick'):
                            emit(c)
                        bricks.append(('OP_LOOP_END', 0, 0, start))
                    else:
                        raise SystemExit('unsupported brick: ' + t)

                for b in s.find('brickList').findall('brick'):
                    emit(b)
                arr = 's%d_%d_sc%d' % (si, pi, si2)
                C.append('static const Brick %s[] = {' % arr)
                for (o_, a, b_, i) in bricks:
                    C.append('  {%s, %.4ff, %.4ff, %d},' % (o_, a, b_, i))
                if not bricks:
                    C.append('  {OP_HIDE,0,0,0},')
                C.append('};')
                scripts_c.append('{%s, %d, %d, %s}' % (kind, m, len(bricks), arr))
            C.append('static const Look s%d_%d_looks[] = {%s};' % (
                si, pi, ','.join('{%d,%d,%d}' % l for l in looks) or '{0,0,0}'))
            C.append('static const Script s%d_%d_scripts[] = {%s};' % (
                si, pi, ','.join(scripts_c) or '{SC_START,0,0,NULL}'))
            nm = o.get('name').strip().replace('"', "'")
            spr_c.append('{"%s", %d, s%d_%d_looks, %d, s%d_%d_scripts}' % (
                nm, len(looks), si, pi, len(scripts_c), si, pi))
        C.append('static const SpriteDef s%d_sprites[] = {%s};' % (si, ',\n  '.join(spr_c)))
        scene_c.append('{"%s", %d, s%d_sprites}' % (sname, len(spr_c), si))

    final = ['/* GENERATED by tools/convert.py -- do not edit */',
             '#include <stddef.h>', '#include "game.h"', ''] + C
    final.append('const SceneDef g_scenes[] = {\n  %s\n};' % ',\n  '.join(scene_c))
    final.append('const int g_nscenes = %d;' % len(scene_c))
    final.append('const SoundDef g_sounds[] = {%s};' % ','.join('{%d}' % s for s in snd_list))
    final.append('const int g_nsounds = %d;' % len(snd_list))
    final.append('const TexDef g_texdefs[] = {%s};' % ','.join('{%d,%d,%d,%d}' % t for t in tex_list))
    final.append('const int g_ntex = %d;' % len(tex_list))
    final.append('const int g_stage_w = %d, g_stage_h = %d;' % (SW, SH))
    open(out + '/gamedata.c', 'w').write('\n'.join(final) + '\n')

    tot = sum(os.path.getsize('%s/romfs/tex/%s' % (out, f)) for f in os.listdir(out + '/romfs/tex'))
    print('scenes:', len(scene_c), 'textures:', len(tex_list), 'sounds:', len(snd_list), 'messages:', messages)
    print('texture bytes: %.1f MB' % (tot / 1e6))
    shutil.rmtree(work)


if __name__ == '__main__':
    main()
